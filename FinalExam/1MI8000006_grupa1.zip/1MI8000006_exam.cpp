// 1MI8000006_exam.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <cstring>
#include <fstream>

template <typename T>
class DigitSound
{
protected:
	unsigned duration;
	T maxBorder;
	T minBorder;
	T* samples;

	void copy(const DigitSound<T>& other)
	{
		this->duration = other.duration;
		this->maxBorder = other.maxBorder;
		this->minBorder = other.minBorder;
		this->samples = new(std::nothrow) T[this->duration];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		for (unsigned i = 0; i < this->duration; i++)
		{
			this->samples[i] = other.samples[i];
		}
	}
	void destroy()
	{
		delete[]this->samples;
		this->duration = 0;
		this->maxBorder = 1;
		this->minBorder = -1;
	}
public:
	DigitSound()
	{
		this->duration = 0;
		this->maxBorder = 1;
		this->minBorder = -1;
		this->samples = nullptr;
	}
	DigitSound(const unsigned& duration, const T& border)
	{
		if (duration < 0 || border < 0)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->duration = duration;
		this->maxBorder = border;
		this->minBorder -= border;
	}
	//DigitSound(const unsigned& duration, const T& border, const T* samples)
	//{
	//	if (samples == nullptr || duration < 0 || border < 0)
	//	{
	//		throw std::invalid_argument("Invalid data");
	//	}
	//	this->duration = duration;
	//	this->maxBorder = border;
	//	this->minBorder -= border;
	//	this->samples = new(std::nothrow) T[this->duration];
	//	if (!this->samples)
	//	{
	//		delete[]this->samples;
	//		throw;
	//	}
	//	for (unsigned i = 0; i < this->duration; i++)
	//	{
	//		if (samples[i] > maxBorder || samples[i] < minBorder)
	//		{
	//			delete[]this->samples;
	//			throw std::invalid_argument("Invalid data");
	//		}
	//		this->samples[i] = samples[i];
	//	}
	//}
	DigitSound(const DigitSound<T>& other)
	{
		copy(other);
	}
	DigitSound& operator=(const DigitSound<T>& other)
	{
		if (this != &other)
		{
			destroy();
			copy(other);
		}
		return *this;
	}
	virtual ~DigitSound()
	{
		destroy();
	}

	T& operator[](const unsigned& index) const
	{
		if (index >= duration)
		{
			std::cout << "Invalid number of sample\n";
			throw;
		}
		return samples[index];
	}

	virtual DigitSound<T>* clone() const = 0;

	unsigned getDuration() const
	{
		return this->duration;
	}
	T getMaxBorder() const
	{
		return this->maxBorder;
	}
	T getMinBorder() const
	{
		return this->minBorder;
	}
	void setMinBorder(const T& border)
	{
		this->minBorder = border;
	}
	void setMaxBorder(const T& border)
	{
		this->maxBorder = border;
	}
};

template <typename T>
class QuietSound : public DigitSound<T>
{
public:
	QuietSound(const unsigned& duration, const T& border) : DigitSound<T>(duration, border)
	{
		this->samples = new(std::nothrow) T[this->duration];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		for (unsigned i = 0; i < this->duration; i++)
		{
			this->samples[i] = 0;
		}
	}
	DigitSound<T>* clone() const
	{
		return new QuietSound(*this);
	}
};

template <typename T>
class FileSound : public DigitSound<T>
{
private:
	char* fileName;
public:
	FileSound(const unsigned& duration, const T& border,const char* fileName) : DigitSound<T>(duration,border)
	{
		if (fileName == nullptr)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->fileName = new char[strlen(fileName) + 1];
		strcpy(this->fileName,fileName);
		try
		{
			loadFromFile();
		}
		catch (...)
		{
			std::cout << "Error occurred while loading the file..\n";
			throw;
		}
	}
	~FileSound()
	{
		delete[] this->fileName;
	}
	void loadFromFile()
	{
		std::ifstream in(this->fileName, std::ios::binary);
		if (!in.is_open())
		{
			std::cout << "Can not open file\n";
			throw;
		}
		
		in.seekg(0);
		this->samples = new(std::nothrow) T[this->duration];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		for (unsigned i = 0; i < this->duration; i++)
		{
			in.read((char*)& (this->samples[i]), sizeof(T));
		}
		in.close();
	}
	DigitSound<T>* clone() const
	{
		return new FileSound(*this);
	}
};

template <typename T>
class PeriodicalSound : public DigitSound<T>
{
public:
	PeriodicalSound(const unsigned& duration, const T& border, const T* numbers, const int& repeating) : DigitSound<T>(duration,border)
	{
		if (numbers == nullptr)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->samples = new(std::nothrow) T[this->duration * repeating];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		unsigned ind = 0;
		for (unsigned i = 0; i < repeating; i++)
		{
			for (unsigned j = 0; j < this->duration; j++)
			{
				this->samples[ind++] = numbers[j];
			}
		}
	}
	DigitSound<T>* clone() const
	{
		return new PeriodicalSound(*this);
	}

};
template <typename T>
class MixedSound : public DigitSound<T>
{
private:
	unsigned calculateDuration(const DigitSound<T>** sounds,const unsigned& size)
	{
		unsigned max = -1;
		for (unsigned i = 0; i < size; i++)
		{
			unsigned curr = sounds[i]->getDuration();
			if (curr > max)
			{
				max = curr;
			}
		}
		return max;
	}
	T findSample(const DigitSound<T>* sound, const unsigned& size)
	{
		T sample;
		unsigned sum = 0;
		unsigned dur = sound->getDuration();
		for (unsigned i = 0; i < dur; i++)
		{
			sum += sound->operator[](i);
		}
		sum /= size;
		sample = sum;
		return sample;
	}
public:
	MixedSound(const DigitSound<T>** sounds,const unsigned& size)
	{
		if (sounds == nullptr || size < 0)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->duration = calculateDuration(sounds, size);
		this->samples = new(std::nothrow) T[this->duration];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		for (unsigned i = 0; i < this->duration; i++)
		{
			if (sounds[i] == nullptr)
			{
				throw std::invalid_argument("Invalid data");
			}
			this->samples[i] = findSample(sounds[i], size);
		}
		this->maxBorder = std::max(this->samples);
		this->minBorder = std::min(this->samples);
	}
	DigitSound<T>* clone() const
	{
		return new MixedSound(*this);
	}
};

template <typename T>
class RowSound : public DigitSound<T>
{
private:
	unsigned calculateDuration(const DigitSound<T>** sounds, const unsigned& size)
	{
		unsigned sum = 0;
		for (unsigned i = 0; i < size; i++)
		{
			sum += sounds[i]->getDuration();

		}
		return sum;
	}

public:
	RowSound(const DigitSound<T>** sounds, const unsigned& size)
	{
		if (sounds == nullptr || size < 0)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->duration = calculateDuration(sounds, size);
		this->samples = new(std::nothrow) T[this->duration];
		if (!this->samples)
		{
			delete[]this->samples;
			throw;
		}
		for (unsigned i = 0; i < this->duration; i++)
		{
			this->samples[i] = sounds[i]->operator[](i);
		}

		this->maxBorder = std::max(this->samples);
		this->minBorder = std::min(this->samples);
	}
	DigitSound<T>* clone() const
	{
		return new MixedSound(*this);
	}
};

template <typename T>
class EffectSound : public DigitSound<T>
{
private:
	T(*func)(T& sample, unsigned index,int coeff);
public:
	EffectSound(const DigitSound<T>* sound, T(*func)(T& sample, unsigned index,const int coeff),const int coeff)
	{
		this->func = func;
		for (unsigned i = 0; i < sound->getDuration(); i++)
		{
			this->func(sound->operator[](i), i,coeff);
			if (sound->getMaxBorder() < sound->operator[](i)
				|| sound->getMinBorder() < sound->operator[](i))
			{
				if (sound->operator[](i) < 0)
				{
					sound->operator[](i) = sound->getMinBorder();
				}
				else
				{
					sound->operator[](i) = sound->getMaxBorder();
				}
			}
		
		}
	}
	DigitSound<T>* clone() const
	{
		return new EffectSound(*this);
	}
};

template <typename T>
bool save(const DigitSound<T>* sound, const char* fileName)
{
	std::ofstream out(fileName, std::ios::app);
	if (!out.is_open())
	{
		std::cout << "Can not open file\n";
		return false;
	}
	out << sound->getDuration() << '\n';
	out << sound->getMinBorder << ' ' << sound->getMaxBorder << '\n';
	out.close();
	return out.good();
}


class Playlist
{
private:
	char* fileName;
	DigitSound<float>** sounds;
	unsigned size;
	unsigned capacity;
	const unsigned MAX_BORDER = 1;

	bool isCharacter(char ch)
	{
		return ch >= 'A' && ch <= 'Z';
	}
	bool isDigit(char ch)
	{
		return ch >= '0' && ch <= '9';
	}
	bool isWhitespace(char ch)
	{
		return ch == ' ' || ch == '\t';
	}
	void destroy()
	{
		for (unsigned i = 0; i < size; i++)
		{
			delete sounds[i];
		}
		delete[]sounds;
		size = 0;
		capacity = 0;
		delete[]fileName;
	}
	unsigned findFileSize(const char* file)
	{
		if (file == nullptr)
		{
			throw std::invalid_argument("Invalid data");
		}
		std::ifstream in(file);
		if (!in.is_open())
		{
			std::cout << "Can not open file\n";
			throw;
		}
		in.seekg(0, std::ios::end);
		unsigned size = in.tellg() / sizeof(float);
		in.close();
		return size;
	}
	void resize()
	{
		this->capacity = this->size * 2;
		DigitSound<float>** temp = new DigitSound<float>*[this->capacity];
		for (unsigned i = 0; i < this->size; i++)
		{
			temp[i] = sounds[i];
		}
		sounds = temp;
		for (unsigned i = 0; i < size; i++)
		{
			delete temp[i];
		}
		delete[]temp;
	}
	float changeCoefficient(float& sample, unsigned ind, const int coeff){}
public:
	Playlist(const char* fileName)
	{
		if (fileName == nullptr)
		{
			throw std::invalid_argument("Invalid data");
		}
		this->fileName = new char[strlen(fileName) + 1];
		strcpy(this->fileName, fileName);
		this->capacity = 8;
		this->size = 0;
		this->sounds = new DigitSound<float>*[capacity];
	}
	Playlist& operator=(const Playlist& other) = delete;
	~Playlist()
	{
		destroy();
	}

	void readFromFile()
	{
		std::ifstream in(this->fileName);
		if (!in.is_open())
		{
			std::cout << "Can not open file\n";
			throw;
		}
		unsigned ind = 0;
		while (!in.eof() && !in.fail())
		{
			if (isCharacter(in.peek()))
			{
				char buffer[512];
				in >> buffer;
				int first;
				in >> first;

				unsigned dur = findFileSize(buffer);
				if (isWhitespace(in.peek()))
				{
					in.get();
					if (isDigit(in.peek()))
					{
						float sec;
						in >> sec;
						if (this->capacity <= this->size)
						{
							resize();
						}
						DigitSound<float>** temp = new DigitSound<float>*[size];
						DigitSound<float>* temp1 = new FileSound<float>(dur, MAX_BORDER, buffer);
						//sounds[ind++] = new RowSound<float>(temp, changeCoefficient(), first);
						delete[]temp;
					}
				}
				else
				{
					if (this->capacity <= this->size)
					{
						resize();
					}
					DigitSound<float>* temp = new FileSound<float>(dur,MAX_BORDER,buffer);
					//sounds[ind++] = new EffectSound<float>(temp, changeCoefficient(), first);
					delete[]temp;
				}
			}
			else
			{
				float pauses;
				in >> pauses;
				DigitSound<float>* temp = new QuietSound<float>(pauses,MAX_BORDER);
				if (this->capacity <= this->size)
				{
					resize();
				}
				sounds[ind++] = temp;
				delete[]temp;
			}
		}
		in.close();
	}
};
int main()
{
	return 0;
}
